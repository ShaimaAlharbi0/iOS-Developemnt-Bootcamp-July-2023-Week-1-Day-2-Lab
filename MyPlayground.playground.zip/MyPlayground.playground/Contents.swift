import UIKit
// Task 1: Variable Practice
var i = 0
while i < 10{
    print (i)
    i += 1
}
for score in "Score"{
        print(score)
    
}

// Task 2: Control Flow
let number = 10
if number >= 9 {
    print("Pass")
}
else if (number <= 9){
    print("Fill")
}

//Task 3: Loop Practice
let names = ["Rayan", "Fahad" , "Ahmad", "Ghada", "Layan"]
for name in names {
    print(", \(name)")
    
}
//Task 4: Working with Dictionaries
var emptyDictionary: [String: Int] = [:]
var fruits = ["apple": 3, "cherry":7 , "Strawberry":2 ,"grapes":8]
for (key, value) in fruits {
  print("\(key): \(value)")
}
//Task 5: String Interpolation
let NameString = "Shaima"
var WelcomMessage = (NameString + "Welcom everybody")
print(WelcomMessage)
